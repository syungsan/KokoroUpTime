Rounded M+ FONTS
Rounded M+ 1.059.20150529 (based on M+ FONTS TESTFLIGHT-059)


'Rounded M+ FONTS' is a modification of 'M+ OUTLINE FONTS'
in rounded edges.

The license of this font is the same as 'M+ OUTLINE FONTS'.

This release is built with the source of
'M+ OUTLINE FONTS' on 2015-05-29T01:00:00+09:00.


The detailed description (Japanese language)
http://jikasei.me/

Rounded M+ FONTS distribution page (Japanese language)
http://jikasei.me/font/rounded-plus/

Original description by itouhiro (Japanese language)
http://d.hatena.ne.jp/itouhiro/20120226
